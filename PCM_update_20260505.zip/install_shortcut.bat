@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_shortcut.ps1"
pause
